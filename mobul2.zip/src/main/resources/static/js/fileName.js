const fileInput = document.getElementById('file-upload');
  const fileNameDiv = document.getElementById('fileName');

  // 파일 선택 시 파일명을 추출하여 보여주는 함수
  fileInput.onchange = function() {
    // 선택된 파일 객체 가져오기
    const file = fileInput.files[0];
    // 파일명 추출
    const fileName = file.name;
    // 파일명을 보여주는 영역에 텍스트로 출력
    fileNameDiv.textContent = fileName;
  };