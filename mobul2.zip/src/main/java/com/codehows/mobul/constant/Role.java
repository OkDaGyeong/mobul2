package com.codehows.mobul.constant;

public enum Role {
    USER, ADMIN
}
