package com.codehows.mobul.config;

public class UsersConfig {
}
