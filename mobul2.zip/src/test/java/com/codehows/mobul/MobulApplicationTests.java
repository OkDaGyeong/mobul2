package com.codehows.mobul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobulApplicationTests {

	@Test
	void contextLoads() {
	}

}
