개발환경
- IntelliJ IDEA Community Edition
- amazon corretto open jdk 11
- mysql 8
- JPA
- thymeleafe 

주요 기능
- 회원가입
- 로그인
- 리스트 조회
- 수정
- 삭제
- 등등 